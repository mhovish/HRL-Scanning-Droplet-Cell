# SDC Control — modular OCV → LSV

Refactor of uploaded `OCV_LSVMeshLvl.ipynb` and `sdc_mesh_leveling.py`. The original LSV CV-backend implementation and default technique/pump/grid parameters are retained.

## Setup

Use the same Windows Python environment and tested versions of `easy_biologic`, `pyserial`, `requests`, `numpy`, `nest_asyncio`, and Jupyter as the original notebook. From the project directory:

```powershell
python -m pip install -e .
python -m pytest tests
```

Open `notebooks/01_ocv_lsv_experiment.ipynb`. Edit connection values, sample coordinates, data directory, and safety settings before running. **It will control real hardware.** `run()` calibrates four corners by default. Setting `calibrate_corners=False` requires an explicitly passed, verified plane.

## Layout
- `sdc/hardware/`: printer / syringe pump
- `sdc/calibration/`: four-corner fit + coordinates
- `sdc/techniques/`: original LSV technique and OCV/LSV runners
- `sdc/core/`: row-major grid, interactive recovery, experiment controller
- `sdc/config.py`: original default values
- `tests/`: hardware-free tests

## Important validation before use
This is **not hardware-validated**. Check Klipper movement direction, travel clearance across the entire sample and fixtures, coordinate offsets, feed rates, pump status responses, BioLogic technique stop behavior, and the actual serial/ethernet settings. The original `LSV` uses a CV backend with `Scan_number=1` and `N_Cycles=0`—confirm actual waveforms and end-hold behavior on your instrument. `M400` is used instead of polling `print_stats`. A serial pump timeout guards against endless status polling. The original `dataocv`/`datalsv` CSV layout is preserved. Recovery remains operator-driven; a nonempty file is not proof of good contact. There is no automatic resume or potentiostat emergency output-off implementation; integrate those against the instrument API before unattended operation.

### Safety difference
At each grid coordinate the module retracts to a precomputed *maximum* clearance plane height before XY travel, rather than using the original constant `REF_Z + CLEARANCE_Z`. This prevents deliberate diagonal moves near the surface but does not guarantee fixture clearance; verify mechanically. Do not operate unattended until you have validated fail-safe behaviors.
